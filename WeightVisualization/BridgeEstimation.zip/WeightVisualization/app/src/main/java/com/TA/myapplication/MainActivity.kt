package com.TA.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.TA.myapplication.databinding.ActivityMainBinding
import com.anychart.AnyChart
import com.anychart.chart.common.dataentry.DataEntry
import com.anychart.chart.common.dataentry.ValueDataEntry
import com.anychart.charts.Pie

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val pie : Pie = AnyChart.pie()
        val data  = ArrayList<ValueDataEntry>()
        data.add(ValueDataEntry("John",10000))
        data.add(ValueDataEntry("Jow",230000))
        data.add(ValueDataEntry("Ricki",23123))

        pie.data(data as List<ValueDataEntry>)

        binding.anyChartView.setChart(pie)
    }
}